# What isValidLicense answers

    mvn compile exec:java -Dexec.mainClass=Probe

Five product names, three real, one that does not exist, and the empty string.
Run it once as you are, and once with no key at all:

    mvn compile exec:java -Dexec.mainClass=Probe \
        -Dexec.args="" -Duser.home=/tmp/no-key

Needs the network, because the check calls home.
