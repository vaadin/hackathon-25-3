import com.vaadin.pro.licensechecker.BuildType;
import com.vaadin.pro.licensechecker.LicenseChecker;

public class Probe {
    public static void main(String[] args) {
        String[] products = { "vaadin-grid-pro", "vaadin-charts", "vaadin-core",
                              "a-product-that-does-not-exist", "" };
        for (String product : products) {
            try {
                boolean valid = LicenseChecker.isValidLicense(product, "25.3.0", BuildType.DEVELOPMENT);
                System.out.printf("%-32s -> %s%n", "\"" + product + "\"", valid);
            } catch (RuntimeException failure) {
                System.out.printf("%-32s -> threw %s%n", "\"" + product + "\"",
                        failure.getClass().getSimpleName());
            }
        }
    }
}
