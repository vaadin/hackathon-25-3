package com.example;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Pre;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.streams.UploadHandler;

/**
 * An Upload with maxFiles(1) and an add button the application supplied.
 *
 * Choose a file, then press the button again. Nothing happens, and the server
 * still believes the button it created is enabled.
 */
@Route("latch")
public class LatchView extends VerticalLayout {

    public LatchView() {
        var chosen = new Pre("nothing chosen yet");

        var upload = new Upload(UploadHandler.inMemory(
                (metadata, data) -> chosen.setText("server received " + metadata.fileName()
                        + ", " + data.length + " bytes")));
        upload.setMaxFiles(1);
        upload.setDropAllowed(false);

        var ours = new Button("Choose a file");
        upload.setUploadButton(ours);

        var serverSide = new Pre();
        var browserSide = new Pre();
        browserSide.setId("browser-side");

        add(new H2("vaadin-upload disables an add button the application owns"),
                new Paragraph("1. Press \"Choose a file\" and pick anything. "
                        + "2. Press it again: no file chooser opens. "
                        + "3. Press \"What does each side think?\"."),
                upload, chosen,
                new Button("What does each side think?", event -> {
                    serverSide.setText("server:  upload.isEnabled()=" + upload.isEnabled()
                            + "   ourButton.isEnabled()=" + ours.isEnabled());
                    // Written straight into the page by the browser, so nothing
                    // about this measurement depends on a value travelling back.
                    upload.getElement().executeJs(
                            "const button = this.querySelector('[slot=add-button]');"
                                    + "document.getElementById('browser-side').textContent ="
                                    + "  'browser: maxFilesReached=' + this.maxFilesReached"
                                    + "  + '   addButton.disabled=' + button.disabled"
                                    + "  + '   files=' + this.files.length;");
                }),
                serverSide, browserSide);
    }
}
