package com.example;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Pre;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.streams.UploadHandler;

/**
 * The `capture` attribute, which the web component supports and the Flow
 * component has no setter for.
 */
@Route("capture")
public class CaptureView extends VerticalLayout {

    public CaptureView() {
        var plain = upload("Choose a photo");
        var camera = upload("Take a photo");
        // The only way to reach it from Java: a property name in a string.
        camera.getElement().setProperty("capture", "environment");

        var report = new Pre();
        report.setId("report");

        add(new H2("Upload has no Java setter for the file input's capture attribute"),
                new Paragraph("On a phone the first button opens the file browser and the "
                        + "second opens the camera. The difference is one attribute on the "
                        + "component's own file input. The web component has the property; "
                        + "com.vaadin.flow.component.upload.Upload has no method for it."),
                plain, camera,
                new Button("Read both file inputs", event -> camera.getElement().executeJs(
                        "const uploads = [...document.querySelectorAll('vaadin-upload')];"
                                + "document.getElementById('report').textContent ="
                                + "  uploads.map((u, i) => 'upload ' + i + ' capture=' +"
                                + "    u.shadowRoot.querySelector('input[type=file]')"
                                + "      .getAttribute('capture')).join('\\n');")),
                report);
    }

    private Upload upload(String label) {
        var upload = new Upload(UploadHandler.inMemory((metadata, data) -> {
        }));
        upload.setAcceptedMimeTypes("image/*");
        upload.setDropAllowed(false);
        upload.setUploadButton(new Button(label));
        return upload;
    }
}
