package com.example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.vaadin.flow.component.grid.Grid;
import org.junit.jupiter.api.Test;

/**
 * A filter row under the column titles cannot have a filter that spans two
 * columns. The same join on a prepended row is fine.
 *
 * No browser and no Spring: the refusal is a server side exception.
 */
class HeaderJoinTest {

    private record Row(String a, String b, String c) {
    }

    private Grid<Row> grid() {
        var grid = new Grid<Row>();
        grid.addColumn(Row::a).setHeader("A").setKey("a");
        grid.addColumn(Row::b).setHeader("B").setKey("b");
        grid.addColumn(Row::c).setHeader("C").setKey("c");
        return grid;
    }

    @Test
    void joiningOnAnAppendedHeaderRowIsRefused() {
        var grid = grid();
        var filters = grid.appendHeaderRow();

        var refused = assertThrows(IllegalArgumentException.class,
                () -> filters.join(filters.getCell(grid.getColumnByKey("a")),
                        filters.getCell(grid.getColumnByKey("b"))));

        assertEquals("Cells can be joined only on the top-most HeaderRow or the bottom-most FooterRow.",
                refused.getMessage());
    }

    @Test
    void joiningOnAPrependedHeaderRowWorks() {
        var grid = grid();
        var filters = grid.prependHeaderRow();

        var joined = filters.join(filters.getCell(grid.getColumnByKey("a")),
                filters.getCell(grid.getColumnByKey("b")));

        assertNotNull(joined, "the same call, one row higher, is allowed");
    }
}
