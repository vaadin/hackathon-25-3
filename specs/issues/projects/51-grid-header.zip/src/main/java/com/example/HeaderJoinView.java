package com.example;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Pre;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;
import java.util.List;

/**
 * The same join, once under the titles and once above them.
 *
 * A filter row belongs under the column it filters. A search field that covers
 * the columns with no filter of their own has to span them. Only one of those
 * two is possible.
 */
@Route("join")
public class HeaderJoinView extends VerticalLayout {

    public record Product(String name, String price, String stock, String category) {
    }

    private static final List<Product> ROWS = List.of(
            new Product("Almond biscotti", "2.00", "32", "Cookies"),
            new Product("Baguette", "2.60", "16", "Breads"),
            new Product("Carrot cake", "24.00", "34", "Cakes"));

    public HeaderJoinView() {
        setWidthFull();
        add(new H2("A grid header row can only be joined if it is the top-most one"));

        add(new H3("appendHeaderRow, which is where a filter row belongs"));
        var refused = new Pre();
        var under = grid();
        var below = under.appendHeaderRow();
        try {
            below.join(below.getCell(under.getColumnByKey("name")),
                    below.getCell(under.getColumnByKey("price")),
                    below.getCell(under.getColumnByKey("stock")))
                    .setComponent(search());
        } catch (IllegalArgumentException failure) {
            refused.setText(failure.getClass().getSimpleName() + ": " + failure.getMessage());
            below.getCell(under.getColumnByKey("name")).setComponent(search());
        }
        add(under, refused,
                new Paragraph("So the filter is one column wide, and the two columns beside "
                        + "it have an empty cell each."));

        add(new H3("prependHeaderRow, the same call one row higher"));
        var over = grid();
        var above = over.prependHeaderRow();
        above.join(above.getCell(over.getColumnByKey("name")),
                above.getCell(over.getColumnByKey("price")),
                above.getCell(over.getColumnByKey("stock")))
                .setComponent(search());
        add(over, new Paragraph("It spans, and the filters are now above the titles rather "
                + "than under them."));
    }

    private TextField search() {
        var field = new TextField();
        field.setPlaceholder("Search products");
        field.setWidthFull();
        return field;
    }

    private Grid<Product> grid() {
        var grid = new Grid<Product>();
        grid.addColumn(Product::name).setHeader("Name").setKey("name");
        grid.addColumn(Product::price).setHeader("Price").setKey("price");
        grid.addColumn(Product::stock).setHeader("Stock").setKey("stock");
        grid.addColumn(Product::category).setHeader("Category").setKey("category");
        grid.setItems(ROWS);
        grid.setAllRowsVisible(true);
        return grid;
    }
}
