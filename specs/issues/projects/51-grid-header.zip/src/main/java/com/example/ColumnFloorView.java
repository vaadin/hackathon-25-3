package com.example;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Pre;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import java.util.List;

/**
 * What a column does when the grid is narrower than its columns want.
 *
 * `Grid.Column` has `setWidth`, `setAutoWidth` and `setFlexGrow` and nothing
 * named for a minimum. This prints what each column actually measures at 1000
 * pixels and at 360, so the question is answered by a number.
 */
@Route("floor")
public class ColumnFloorView extends VerticalLayout {

    public record Product(String name, String price, String stock, String category) {
    }

    private static final List<Product> ROWS = List.of(
            new Product("Ham and cheese sandwich", "5.20", "16", "Savoury"),
            new Product("Almond biscotti", "2.00", "32", "Cookies"));

    private final Div box = new Div();
    private final Pre report = new Pre();

    public ColumnFloorView() {
        var grid = new Grid<Product>();
        // A width and a share of the slack. The question is whether the width
        // survives a container narrower than the sum of the columns.
        grid.addColumn(Product::name).setHeader("Name").setKey("name")
                .setWidth("14rem").setFlexGrow(2);
        grid.addColumn(Product::price).setHeader("Price").setKey("price")
                .setWidth("6rem").setFlexGrow(0);
        grid.addColumn(Product::stock).setHeader("Stock").setKey("stock")
                .setWidth("6rem").setFlexGrow(0);
        grid.addColumn(Product::category).setHeader("Category").setKey("category")
                .setWidth("8rem").setFlexGrow(1);
        grid.setItems(ROWS);
        grid.setAllRowsVisible(true);
        grid.setWidthFull();

        box.setWidth("1000px");
        box.add(grid);

        add(new H2("Does a column width act as a minimum?"),
                new Paragraph("The name column asks for 14rem, which is 224 pixels, and grows. "
                        + "Narrow the box below the sum of the four widths and read what it measures."),
                new Button("1000 px", event -> resize("1000px", grid)),
                new Button("360 px", event -> resize("360px", grid)),
                box, report);
        resize("1000px", grid);
    }

    private void resize(String width, Grid<Product> grid) {
        box.setWidth(width);
        grid.getElement().executeJs(
                "return new Promise(resolve => requestAnimationFrame(() => {"
                        + "  const cells = [...this.querySelectorAll('vaadin-grid-cell-content')]"
                        + "    .slice(0, 4);"
                        + "  resolve('box ' + this.parentElement.getBoundingClientRect().width"
                        + "    + 'px, columns ' + cells.map(c =>"
                        + "        Math.round(c.getBoundingClientRect().width)).join(' | '));"
                        + "}));")
                .then(String.class, report::setText);
    }
}
