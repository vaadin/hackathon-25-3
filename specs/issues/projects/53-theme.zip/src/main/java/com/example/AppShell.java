package com.example;

import com.vaadin.flow.component.dependency.StyleSheet;
import com.vaadin.flow.component.page.AppShellConfigurator;
import com.vaadin.flow.theme.aura.Aura;

/**
 * The theme, declared the way the documentation declares it, so the comparison
 * is not confused by anything to do with adding a stylesheet at runtime.
 *
 * Swap the two annotations below and restart to see the same page under Lumo.
 */
@StyleSheet(Aura.STYLESHEET)
// @StyleSheet(com.vaadin.flow.theme.lumo.Lumo.STYLESHEET)
public class AppShell implements AppShellConfigurator {
}
