package com.example;

import com.vaadin.flow.component.badge.Badge;
import com.vaadin.flow.component.badge.BadgeVariant;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Pre;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;

/**
 * Two style names that mean something under Lumo and nothing under Aura, with
 * the portable equivalent of each beside it.
 *
 * Nothing here is exotic. `theme="badge"` on a Span is how every Vaadin
 * application since 14 has drawn a badge, and it is what the Bakery starter
 * still does; `LUMO_TERTIARY_INLINE` is how an icon button is made bare.
 */
@Route("names")
public class ThemeNamesView extends VerticalLayout {

    private final Pre report = new Pre();

    public ThemeNamesView() {
        var themedSpan = new Span("theme=badge span");
        themedSpan.getElement().getThemeList().add("badge");
        themedSpan.setId("themed-span");

        var badge = new Badge("Badge component");
        badge.setId("badge-component");
        badge.addThemeVariants(BadgeVariant.SMALL);

        var lumoInline = new Button("LUMO_TERTIARY_INLINE");
        lumoInline.addThemeVariants(ButtonVariant.LUMO_TERTIARY_INLINE);
        lumoInline.setId("lumo-inline");

        var tertiary = new Button("TERTIARY");
        tertiary.addThemeVariants(ButtonVariant.TERTIARY);
        tertiary.setId("tertiary");

        add(new H2("Lumo style names that are silently inert under Aura"),
                new Paragraph("The theme is declared in AppShell.java. Swap the two lines "
                        + "there and restart to compare."),
                new H3("A badge"),
                new HorizontalLayout(themedSpan, badge),
                new H3("A button meant to be a bare icon"),
                new HorizontalLayout(lumoInline, tertiary),
                new Button("Measure", event -> measure()),
                report);
        setWidthFull();
    }

    private void measure() {
        getElement().executeJs(
                "const read = id => {"
                        + "  const e = document.getElementById(id);"
                        + "  const s = getComputedStyle(e);"
                        + "  return id.padEnd(16) + ' background=' + s.backgroundColor"
                        + "    + '  color=' + s.color + '  padding=' + s.padding"
                        + "    + '  border=' + s.borderTopWidth + ' ' + s.borderTopStyle;"
                        + "};"
                        + "return 'theme: ' + (document.querySelector('style#aura') ? 'aura' : '')"
                        + "  + [...document.querySelectorAll('link[rel=stylesheet]')]"
                        + "      .map(l => l.href.split('/').pop()).join(',')"
                        + "  + '\\n' + ['themed-span', 'badge-component', 'lumo-inline', 'tertiary']"
                        + "      .map(read).join('\\n');")
                .then(String.class, report::setText);
    }
}
