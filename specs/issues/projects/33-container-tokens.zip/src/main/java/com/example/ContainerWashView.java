package com.example;

import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Pre;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;

/**
 * The same page and the same two shared tokens, on the base styles, on Lumo and
 * on Aura.
 *
 * The Base Styles page says --vaadin-background-container is "computed from
 * --vaadin-text-color and --vaadin-background-color by default". This page sets
 * exactly those two, and reads back what the browser paints.
 */
@Route("")
public class ContainerWashView extends VerticalLayout {

    private final Pre report = new Pre();

    public ContainerWashView() {
        var page = new Div(
                row(swatch("swatch--page", "--vaadin-background-color", "page"),
                        swatch("swatch--container", "--vaadin-background-container",
                                "container"),
                        swatch("swatch--strong", "--vaadin-background-container-strong",
                                "strong")));
        page.addClassName("page");

        report.addClassName("report");

        add(new H2("Where the container background wash is computed from"),
                new Paragraph("The application sets --vaadin-background-color and "
                        + "--vaadin-text-color, and nothing else. The theme is declared in "
                        + "AppShell.java: swap the two lines there and restart, or comment "
                        + "both out to run on the base styles alone."),
                toggle("Dark page, set through the same two shared tokens", "dark-page"),
                toggle("Also set color-scheme: dark, which is what Page.setColorScheme sets",
                        "dark-scheme"),
                toggle("Also set the theme's own background property "
                        + "(--lumo-base-color / --aura-background-color-*)",
                        "theme-own-background"),
                toggle("Under Lumo, override --lumo-contrast-5pct and -10pct instead",
                        "lumo-contrast"),
                new H3("Two container panels on a page"),
                page,
                new Paragraph("Read back from the browser and composited over the page "
                        + "colour, so the translucent washes can be compared as colours:"),
                report);
        setWidthFull();
        setMaxWidth("980px");

        // Queued until the element attaches, which is enough for a first reading.
        measure();
    }

    private Checkbox toggle(String label, String className) {
        var checkbox = new Checkbox(label);
        checkbox.addValueChangeListener(event -> {
            getElement().executeJs("document.documentElement.classList.toggle($0, $1)",
                    className, event.getValue());
            measure();
        });
        return checkbox;
    }

    private Div row(Div... swatches) {
        var row = new Div(swatches);
        row.addClassName("row");
        return row;
    }

    private Div swatch(String variant, String token, String id) {
        var div = new Div(new Text(token));
        div.addClassNames("swatch", variant);
        div.setId(id);
        return div;
    }

    /**
     * Reads the painted colour rather than the declaration, through a canvas, so
     * that color-mix, oklch and light-dark are all resolved by the browser and
     * the translucent washes come back composited over the page colour.
     */
    private void measure() {
        getElement().executeJs("""
                const canvas = document.createElement('canvas');
                canvas.width = canvas.height = 1;
                const ctx = canvas.getContext('2d', { willReadFrequently: true });
                const painted = (element, over) => {
                  ctx.clearRect(0, 0, 1, 1);
                  if (over) {
                    ctx.fillStyle = over;
                    ctx.fillRect(0, 0, 1, 1);
                  }
                  ctx.fillStyle = getComputedStyle(element).backgroundColor;
                  ctx.fillRect(0, 0, 1, 1);
                  const [r, g, b] = ctx.getImageData(0, 0, 1, 1).data;
                  return '#' + [r, g, b].map(v => v.toString(16).padStart(2, '0')).join('');
                };
                const root = getComputedStyle(document.documentElement);
                const paper = getComputedStyle(document.querySelector('.page')).backgroundColor;
                const sheets = [...document.querySelectorAll('link[rel=stylesheet]')]
                  .map(link => link.href.split('/').pop()).join(', ');
                const line = ([id, token]) => ('  ' + token).padEnd(40)
                  + 'painted ' + painted(document.getElementById(id), paper)
                  + '   declared ' + root.getPropertyValue(token).trim().slice(0, 60);
                return 'stylesheets    ' + sheets
                  + '\\nroot classes   ' + (document.documentElement.className || '(none)')
                  + '\\ncolor-scheme   ' + root.colorScheme
                  + '\\n\\n'
                  + [['page', '--vaadin-background-color'],
                     ['container', '--vaadin-background-container'],
                     ['strong', '--vaadin-background-container-strong']]
                      .map(line).join('\\n');
                """).then(String.class, report::setText);
    }
}
