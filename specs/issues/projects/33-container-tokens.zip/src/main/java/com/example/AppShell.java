package com.example;

import com.vaadin.flow.component.dependency.StyleSheet;
import com.vaadin.flow.component.page.AppShellConfigurator;

/**
 * The theme, declared the way the documentation declares it.
 *
 * Exactly one of the two theme lines below is active. Swap them and restart to
 * run the same page under Lumo and under Aura. With both commented out the
 * application runs on the base styles alone, which is the case the Base Styles
 * page of the documentation describes.
 */
// @StyleSheet(com.vaadin.flow.theme.lumo.Lumo.STYLESHEET)
@StyleSheet(com.vaadin.flow.theme.aura.Aura.STYLESHEET)
@StyleSheet("/styles/repro.css")
public class AppShell implements AppShellConfigurator {
}
