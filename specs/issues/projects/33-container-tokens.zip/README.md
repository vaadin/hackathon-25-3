# Where the container background wash is computed from

The Base Styles page says:

> `--vaadin-background-container`: Background for "containers", buttons, toolbars, notifications, and highlighted content areas. Computed from `--vaadin-text-color` and `--vaadin-background-color` by default.

This project sets exactly those two properties, on `html:root`, in `src/main/resources/META-INF/resources/styles/repro.css`, and nothing else. It then paints three panels and reads back what the browser actually paints, through a canvas, so `color-mix`, `oklch` and `light-dark` are all resolved by the browser rather than by eye.

## Running it

```
mvn spring-boot:run
```

Then open http://localhost:8154. The theme is declared in `src/main/java/com/example/AppShell.java`: exactly one of the two `@StyleSheet` lines is active, and with both commented out the application runs on the base styles alone. Swap them and restart to compare.

The checkboxes on the page add classes to `<html>`, each one a rule in `repro.css`:

| Checkbox | What it adds |
| --- | --- |
| Dark page | the same two shared tokens, given a dark pair |
| `color-scheme: dark` | what `Page.setColorScheme` sets |
| The theme's own background property | `--lumo-base-color`, `--aura-background-color-light/dark` |
| Lumo's contrast scale | `--lumo-contrast-5pct` and `-10pct`, restated as the base formula |

## What it prints

Measured on 25.3.0-beta1, Chrome 141, as `page / container / strong`, each composited over the page colour.

| Stylesheet | light pair, `#fbf7f2` on `#2a2119` | dark pair, `#16130f` on `#f3ece4` |
| --- | --- | --- |
| Base styles, no theme | `#fbf7f2 / #efebe6 / #e4dfd9` | `#16130f / #1f1c17 / #282520` |
| Lumo | `#fbf7f2 / #efedea / #e4e3e3` | `#16130f / #151513 / #161717` |
| Aura | `#fbf7f2 / #f1ede8 / #e5e1dd` | `#16130f / #15120e / #14110d` |

The base styles do what the page describes: the wash tracks both tokens, and in the dark pair the panels come out lighter than the page. Under either theme the two shared tokens do not reach the wash at all, and in the dark pair the container is painted *darker* than the page it sits on, so the panels disappear.

Adding `color-scheme: dark` restores the dark pair, because that is what the themes actually switch on:

| Stylesheet | dark pair plus `color-scheme: dark` |
| --- | --- |
| Lumo | `#16130f / #1f1e1c / #2a2c2d` |
| Aura | `#16130f / #1f1c19 / #292724` |

What does not restore it, and what does, under Lumo:

| Also set | container, light pair |
| --- | --- |
| `--lumo-base-color: #fbf7f2` | `#efedea`, unchanged |
| `--lumo-shade: #2a2119` | `#efedea`, unchanged, because `--lumo-shade-5pct` is a literal `rgba(25, 59, 103, .05)` rather than a mix of `--lumo-shade` |
| `--lumo-contrast-5pct` and `-10pct` | `#f0ece6`, one step off the base styles' `#efebe6` |

## Where the values come from

```
@vaadin/component-base/src/styles/style-props.js
  --vaadin-background-container: color-mix(in oklab, var(--vaadin-text-color) 5%, var(--vaadin-background-color))

@vaadin/vaadin-lumo-styles/src/props/color.css
  --vaadin-background-container: var(--lumo-contrast-5pct)
  --lumo-contrast-5pct: light-dark(var(--lumo-shade-5pct), var(--lumo-tint-5pct))
  --lumo-shade-5pct:   light-dark(rgba(25, 59, 103, .05), rgba(0, 0, 0, .07))

@vaadin/aura/src/color.css
  --vaadin-background-container: color-mix(in srgb, var(--_color-base) calc(3% + min(3%, 1% * var(--aura-contrast-level))), transparent)
  --_color-base: light-dark(oklch(from var(--aura-background-color-light) 0.1 ... h), oklch(from var(--aura-background-color-dark) 1 c h))
```

`images/container-wash.png` is the six cases side by side.
