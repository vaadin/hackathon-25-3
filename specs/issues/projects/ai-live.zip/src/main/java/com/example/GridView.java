package com.example;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.ai.grid.AIDataRow;
import com.vaadin.flow.component.ai.grid.GridAIController;
import com.vaadin.flow.component.ai.orchestrator.AIOrchestrator;
import com.vaadin.flow.component.ai.orchestrator.ResponseListener;
import com.vaadin.flow.component.ai.provider.SpringAILLMProvider;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Pre;
import com.vaadin.flow.component.messages.MessageList;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.auth.AnonymousAllowed;
import java.util.function.Supplier;

/**
 * A grid the model fills by writing SQL, over a table with a TIME column, and
 * a second question whose query the database refuses.
 *
 * The meter under the grid is everything a person can see about the turn: what
 * the response listener was handed, and whether it carried an error.
 */
@Route("grid")
@AnonymousAllowed
public class GridView extends VerticalLayout {

    private final Pre meter = new Pre("no turn yet");
    private int turns;
    /**
     * The response listener runs on the provider's thread with no session
     * lock, so touching a component from it throws
     * "Cannot access state in VaadinSession or UI without locking the session"
     * and the orchestrator swallows it as "Error in response listener". The UI
     * is captured here and the work goes through access().
     */
    private UI ui;

    public GridView(Supplier<SpringAILLMProvider> providers, TimesDatabase database) {
        whenAttached(attached -> {
            ui = attached;
            return () -> {
            };
        });

        var grid = new Grid<AIDataRow>();
        grid.setHeight("240px");

        var controller = new GridAIController(grid, database);
        var messages = new MessageList();
        messages.setMarkdown(true);

        var orchestrator = AIOrchestrator
                .builder(providers.get(), "Answer questions about the appointments table by querying it.")
                .withMessageList(messages)
                .withController(controller)
                .withResponseListener(this::record)
                .build();

        add(new H3("A grid filled by the model, over a TIME column"),
                new Paragraph("The first question needs the TIME column. The second one asks about "
                        + "a table that does not exist, so the query fails."),
                new Button("list every appointment with its time",
                        event -> orchestrator.prompt("List every appointment with who it is for and its time.")),
                new Button("ask about a table that does not exist",
                        event -> orchestrator.prompt("How many rows are in the invoices table?")),
                grid, meter, messages);
        setWidthFull();
    }

    /** Everything the application is told about a turn, printed verbatim. */
    private void record(ResponseListener.ResponseEvent event) {
        turns++;
        ui.access(() -> meter.setText("turns seen by the listener: " + turns
                + "\nerror: " + event.getError().map(Throwable::toString).orElse("(none)")
                + "\nmetadata: " + describe(event)));
    }

    private String describe(ResponseListener.ResponseEvent event) {
        try {
            var metadata = event.getClass().getMethod("getResponseMetadata").invoke(event);
            return String.valueOf(metadata);
        } catch (ReflectiveOperationException | RuntimeException absent) {
            return "(no getResponseMetadata on " + event.getClass().getSimpleName() + ")";
        }
    }
}
