package com.example;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.ai.form.FormAIController;
import com.vaadin.flow.component.ai.orchestrator.AIOrchestrator;
import com.vaadin.flow.component.ai.provider.SpringAILLMProvider;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Pre;
import com.vaadin.flow.component.messages.MessageList;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.auth.AnonymousAllowed;
import java.util.function.Supplier;

/**
 * One form, three questions in one turn.
 *
 * Two fields are direct children of the layout and one is inside a Composite.
 * Source tracking is on, and the report under the buttons prints what each
 * field holds and what the controller says about where the value came from.
 */
@Route("form")
@AnonymousAllowed
public class FormView extends VerticalLayout {

    private final TextField name = new TextField("Customer name");
    private final TextField phone = new TextField("Telephone");
    private final Wrapped wrapped = new Wrapped();
    private final Pre report = new Pre("press fill");
    private final FormAIController controller;

    public FormView(Supplier<SpringAILLMProvider> providers) {
        var form = new FormLayout();
        form.add(name, phone, wrapped);

        controller = new FormAIController(form);
        controller.setSourceTrackingEnabled(true);
        controller.setFieldMarkerEnabled(true);
        controller.describeField(name, "The customer's full name");
        controller.describeField(phone, "The customer's telephone number");
        controller.describeField(wrapped.field(), "Anything the customer asked the baker to do");

        var messages = new MessageList();
        messages.setMarkdown(true);

        var orchestrator = AIOrchestrator
                .builder(providers.get(), "Fill the form from what the user tells you. "
                        + "Use the tools you are given and fill every field you can.")
                .withMessageList(messages)
                .withController(controller)
                .build();

        // Two prompts, and the difference between them is the finding. The
        // first names only what the form can hold. The second also names
        // something whose field is inside a Composite, which the controller
        // never offered, so the model cannot fill it and cannot see why.
        var plain = new Button("fill: only the fields that exist", event -> orchestrator.prompt(
                "The customer is Ana Torres and her telephone is 600123456."));
        var withNote = new Button("fill: also the note the form does not offer", event -> orchestrator.prompt(
                "The customer is Ana Torres, her telephone is 600123456, "
                        + "and she asked for the cake to say Happy Birthday Marta."));

        add(new H3("A form with one field inside a Composite, and source tracking on"),
                new Paragraph("Fill, wait, then report. The note is the field inside the Composite."),
                form, plain, withNote, new Button("report", event -> show()), report, messages);
        setWidthFull();
    }

    /** What the fields hold, and what the controller knows about each. */
    private void show() {
        var text = new StringBuilder();
        text.append(line("name", name));
        text.append(line("phone", phone));
        text.append(line("note (inside the Composite)", wrapped.field()));
        report.setText(text.toString());
    }

    private String line(String label, TextField field) {
        var source = controller.getFieldSource(field);
        return "%-28s value=%-24s source=%s%n".formatted(label,
                field.getValue().isEmpty() ? "(empty)" : field.getValue(),
                source.isPresent() ? source.get() : "(none)");
    }
}
