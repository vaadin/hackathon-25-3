package com.example;

import com.vaadin.flow.component.ai.provider.DatabaseProvider;
import com.vaadin.flow.component.ai.provider.ToolException;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * One table with a real SQL TIME column, and no cleverness: the rows come back
 * as the driver hands them over.
 */
@Component
public class TimesDatabase implements DatabaseProvider {

    private final JdbcTemplate jdbc;

    public TimesDatabase(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
        jdbc.execute("create table if not exists appointments("
                + "id int primary key, who varchar(40), at time, on_day date)");
        if (jdbc.queryForObject("select count(*) from appointments", Integer.class) == 0) {
            jdbc.update("insert into appointments values (1, 'Ana Torres', '07:30:00', '2026-09-09')");
            jdbc.update("insert into appointments values (2, 'Marta Ruiz', '09:00:00', '2026-09-09')");
            jdbc.update("insert into appointments values (3, 'Pablo Alvarez', '16:45:00', '2026-09-10')");
        }
    }

    @Override
    public String getSchema() {
        return """
                One table.

                appointments(id INT, who VARCHAR, at TIME, on_day DATE)
                  One row per appointment. `at` is a SQL TIME column.
                """;
    }

    @Override
    public List<Map<String, Object>> executeQuery(String sql) {
        try {
            return jdbc.queryForList(sql);
        } catch (RuntimeException failure) {
            // What a provider does when the model writes SQL the database
            // refuses. The turn has to end somehow, and this is the documented
            // way to say so.
            throw new ToolException(failure.getMessage());
        }
    }
}
