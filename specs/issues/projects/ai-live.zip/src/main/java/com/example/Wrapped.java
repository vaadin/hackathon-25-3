package com.example;

import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;

/**
 * A field inside a Composite, which is how any application with a reusable
 * sub form arranges one: the form's child is this component, and the field is
 * one level down inside it.
 */
public class Wrapped extends Composite<VerticalLayout> {

    private final TextField note = new TextField("Note for the baker");

    public Wrapped() {
        getContent().setPadding(false);
        getContent().add(note);
    }

    public TextField field() {
        return note;
    }
}
