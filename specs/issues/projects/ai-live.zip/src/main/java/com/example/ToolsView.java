package com.example;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.ai.orchestrator.AIController;
import com.vaadin.flow.component.ai.orchestrator.AIOrchestrator;
import com.vaadin.flow.component.ai.orchestrator.ResponseListener;
import com.vaadin.flow.component.ai.provider.LLMProvider;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.messages.MessageList;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.auth.AnonymousAllowed;
import java.util.List;
import java.util.function.Supplier;
import tools.jackson.databind.JsonNode;

/**
 * Two tools, one with a parameter schema that is not valid JSON, and one turn
 * that needs both.
 *
 * The invalid schema is what a Java text block does to an escaped quote: the
 * source says \" and the string carries a bare " inside a JSON string value.
 */
@Route("tools")
@AnonymousAllowed
public class ToolsView extends VerticalLayout {

    private final Span goodCalls = new Span("set_name calls: 0");
    private final Span badCalls = new Span("set_pickup calls: 0");
    private int good;
    private int bad;
    /** Captured here: a tool runs on the provider's thread, where there is no current UI. */
    private UI ui;

    public ToolsView(Supplier<com.vaadin.flow.component.ai.provider.SpringAILLMProvider> providers) {
        var messages = new MessageList();
        messages.setMarkdown(true);

        var what = new TextField("Ask");
        what.setValue("The customer is Ana Torres and she wants to collect it tomorrow at 09:00.");
        what.setWidthFull();

        var orchestrator = AIOrchestrator
                .builder(providers.get(), "You are taking a counter order. Use the tools you are given: "
                        + "set_name for the customer's name and set_pickup for the collection day and time. "
                        + "Call both, then say in one line what you set.")
                .withMessageList(messages)
                .withController(new TwoTools())
                .withResponseListener(this::report)
                .build();

        whenAttached(attached -> {
            ui = attached;
            return () -> {
            };
        });

        add(new H3("A tool whose schema is not valid JSON"),
                new Paragraph("Press ask, then read the log and the two counters."),
                what,
                new Button("ask", event -> orchestrator.prompt(what.getValue())),
                goodCalls, badCalls, messages);
        setWidthFull();
    }

    private void report(ResponseListener.ResponseEvent event) {
        event.getError().ifPresent(error -> add(new Paragraph("error: " + error)));
    }

    private void counted() {
        goodCalls.setText("set_name calls: " + good);
        badCalls.setText("set_pickup calls: " + bad);
    }

    /** The controller, with one sound tool and one broken one. */
    private class TwoTools implements AIController {

        @Override
        public List<LLMProvider.ToolSpec> getTools() {
            return List.of(new SetName(), new SetPickup());
        }

        @Override
        public void onRequest() {
        }

        @Override
        public void onResponse(ResponseListener.ResponseEvent event) {
        }
    }

    /** Valid schema, so this one is the control. */
    private class SetName implements LLMProvider.ToolSpec {

        @Override
        public String getName() {
            return "set_name";
        }

        @Override
        public String getDescription() {
            return "Record the customer's name.";
        }

        @Override
        public String getParametersSchema() {
            return """
                    {
                      "type": "object",
                      "properties": {
                        "name": { "type": "string", "description": "The customer's name." }
                      },
                      "required": ["name"]
                    }
                    """;
        }

        @Override
        public String execute(JsonNode arguments) {
            good++;
            ui.access(ToolsView.this::counted);
            return "name set to " + arguments.get("name").asString();
        }
    }

    /**
     * The same shape with one difference: the description of `date` quotes the
     * word soonest with escaped double quotes, which is legal Java and illegal
     * JSON once the text block hands over the string.
     */
    private class SetPickup implements LLMProvider.ToolSpec {

        @Override
        public String getName() {
            return "set_pickup";
        }

        @Override
        public String getDescription() {
            return "Record the collection day and time.";
        }

        @Override
        public String getParametersSchema() {
            return """
                    {
                      "type": "object",
                      "properties": {
                        "date": { "type": "string", "description": "Pickup day, or send \"soonest\"." },
                        "time": { "type": "string", "description": "Pickup time as HH:mm." }
                      },
                      "required": []
                    }
                    """;
        }

        @Override
        public String execute(JsonNode arguments) {
            bad++;
            ui.access(ToolsView.this::counted);
            return "pickup set";
        }
    }
}
