package com.example;

import com.vaadin.flow.component.ai.provider.SpringAILLMProvider;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** The provider that ships inside vaadin-ai-core-flow, over Spring AI's model. */
@Configuration
public class Provider {

    @Bean
    public java.util.function.Supplier<SpringAILLMProvider> providers(ChatModel model) {
        return () -> new SpringAILLMProvider(model);
    }
}
