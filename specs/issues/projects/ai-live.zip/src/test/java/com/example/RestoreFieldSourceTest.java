package com.example;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.vaadin.browserless.SpringBrowserlessTest;
import com.vaadin.flow.component.ai.common.ConfidenceLevel;
import com.vaadin.flow.component.ai.common.ValueSource;
import com.vaadin.flow.component.ai.form.FormAIController;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.textfield.TextField;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * `restoreFieldSource` stores the source and does not render the marker.
 *
 * No model and no key: the call is synchronous and offline. The field here is
 * a direct child of the form the controller walks, so this is not about
 * discovery: the controller knows this field and still draws nothing.
 */
@SpringBootTest(classes = Application.class)
class RestoreFieldSourceTest extends SpringBrowserlessTest {

    @Test
    void theSourceComesBackAndTheMarkerDoesNot() {
        var form = new FormLayout();
        var name = new TextField("Customer name");
        form.add(name);
        com.vaadin.flow.component.UI.getCurrent().add(form);

        var controller = new FormAIController(form);
        controller.setSourceTrackingEnabled(true);
        controller.setFieldMarkerEnabled(true);
        controller.describeField(name, "The customer's full name");
        name.setValue("Ana Torres");

        controller.restoreFieldSource(name, new ValueSource(ConfidenceLevel.HIGH, List.of()));

        assertTrue(controller.getFieldSource(name).isPresent(),
                "the source is remembered");
        assertFalse(name.getElement().getChildren()
                .anyMatch(child -> child.getTag().contains("ai-field-marker")),
                "and no marker element is added, which is the half a person can see");
    }
}
