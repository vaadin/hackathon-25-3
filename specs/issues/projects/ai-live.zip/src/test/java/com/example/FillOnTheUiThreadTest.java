package com.example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.vaadin.browserless.SpringBrowserlessTest;
import com.vaadin.flow.component.ai.form.FormAIController;
import com.vaadin.flow.component.ai.orchestrator.AIOrchestrator;
import com.vaadin.flow.component.ai.provider.LLMProvider;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.textfield.TextField;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.springframework.boot.test.context.SpringBootTest;
import reactor.core.publisher.Flux;

/**
 * A provider of our own, so there is no network and no model: it takes the
 * tools it was handed and calls the form's fill tool on the very thread the
 * orchestrator gave it.
 *
 * The timeout is the assertion. A test that hangs proves nothing, so this one
 * fails after ten seconds instead.
 */
@SpringBootTest(classes = Application.class)
@Timeout(value = 20, unit = TimeUnit.SECONDS)
class FillOnTheUiThreadTest extends SpringBrowserlessTest {

    /** Calls fill_form itself, synchronously, and answers with one word. */
    private static class CallsTheToolInline implements LLMProvider {

        private volatile String result = "not called";

        @Override
        public Flux<String> stream(LLMRequest request) {
            var fill = request.explicitTools().stream()
                    .filter(tool -> tool.getName().equals("fill_form"))
                    .findFirst();
            if (fill.isEmpty()) {
                result = "no fill_form among " + request.explicitTools().stream()
                        .map(LLMProvider.ToolSpec::getName).toList();
                return Flux.just("no tool");
            }
            var arguments = tools.jackson.databind.json.JsonMapper.builder().build()
                    .createObjectNode();
            var values = arguments.putObject("values");
            values.put("name", "Ana Torres");
            result = fill.get().execute(arguments);
            return Flux.just("filled");
        }
    }

    @Test
    void aToolCalledOnTheOrchestratorsThreadCompletesOrTheTestSaysSo() {
        var form = new FormLayout();
        var name = new TextField("Customer name");
        form.add(name);
        // The fill tool refuses on a controller whose form is not attached:
        // "fill_form invoked on a controller whose form is not attached to a UI".
        com.vaadin.flow.component.UI.getCurrent().add(form);

        var controller = new FormAIController(form);
        controller.describeField(name, "The customer's full name");

        var provider = new CallsTheToolInline();
        var orchestrator = AIOrchestrator.builder(provider, "fill it")
                .withController(controller)
                .build();

        orchestrator.prompt("The customer is Ana Torres.");

        assertTrue(provider.result != null, "the provider ran");
        assertEquals("Ana Torres", name.getValue(),
                "the field was filled by the tool, and the result was: " + provider.result);
    }
}
